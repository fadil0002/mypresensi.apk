package com.fadil.mypresensi.adapter;

import android.content.Context;

import android.view.LayoutInflater;

import android.view.View;

import android.view.ViewGroup;

import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.fadil.mypresensi.R;
import com.fadil.mypresensi.kelas.anggota;

import java.util.List;

public class DaftarAdapter extends RecyclerView.Adapter<DaftarAdapter.MyViewHolder> {

    private List<anggota> anggota;

    private Context mContext;

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        //Ini adalah item dari item_daftar
        public TextView id, nama, nim, tanggal, jam, status;

        public MyViewHolder(View view) {

            super(view);

            //Ini adalah item dari item_daftar
            id      = view.findViewById(R.id.text_id);

            nama    = view.findViewById(R.id.text_nama);

            nim     = view.findViewById(R.id.text_nim);

            tanggal = view.findViewById(R.id.text_tgl);

            jam     = view.findViewById(R.id.text_jam);

            status  = view.findViewById(R.id.text_status);
        }
    }

    public DaftarAdapter(Context context, List<anggota> anggota) {

        mContext = context;

        this.anggota = anggota;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_daftar, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final anggota anggota1 = anggota.get(position);

        holder.id.setText(anggota1.getId());

        holder.nama.setText(anggota1.getNama());

        holder.nim.setText(anggota1.getNim());

        holder.tanggal.setText(anggota1.getTanggal());

        holder.jam.setText(anggota1.getJam());

        holder.status.setText(anggota1.getStatus());

        if(anggota1.getStatus().equals("1")){

            holder.status.setText("  Hadir  ");

        }else if(anggota1.getStatus().equals("0")){

            holder.status.setText("  Tidak Hadir  ");

        }

    }

    @Override
    public int getItemCount() {
        return anggota.size();
    }
}