package com.fadil.mypresensi.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.fadil.mypresensi.R;

public class  MainActivity extends AppCompatActivity {

    private Button scan, daftar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scan = findViewById(R.id.btn_scan);

        daftar = findViewById(R.id.btn_daftar);

        scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //ketika tombol scan ditekan apa yang terjadi ?
                //ke halaman Scan
                startActivity(new Intent(MainActivity.this,ScanActivity.class));
            }
        });

        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //ketika tombol daftar ditekan apa yang terjadi ?
                //ke halaman Daftar Hadir
                startActivity(new Intent(MainActivity.this,DaftarActivity.class));
            }
        });
    }
}