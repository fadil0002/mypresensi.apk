package com.fadil.mypresensi.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;

import android.database.Cursor;

import com.fadil.mypresensi.R;
import com.fadil.mypresensi.adapter.DaftarAdapter;
import com.fadil.mypresensi.kelas.Database;
import com.fadil.mypresensi.kelas.anggota;

import java.util.ArrayList;

public class DaftarActivity extends AppCompatActivity {

    private Database db;

    private RecyclerView recyclerView;

    private ArrayList<anggota> anggotaArrayList;

    private DaftarAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_daftar);

        setTitle("Detail Kehadiran");

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Mohon menunggu...");
        progressDialog.show();

        db = new Database(this);

        recyclerView = findViewById(R.id.text_rv);

        anggotaArrayList = new ArrayList<>();

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(mAdapter);

        recyclerView.setNestedScrollingEnabled(false);

        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL));

        mAdapter = new DaftarAdapter(this, anggotaArrayList);

        tampilData();

        progressDialog.dismiss();

    }

    private void tampilData() {

        //Untuk clear data list
        anggotaArrayList.clear();

        Cursor c = db.TampilDataAbsen();

        while (c.moveToNext())
        {
            String id = c.getString(0);

            String nim = c.getString(1);

            String nama = c.getString(2);

            String tanggal = c.getString(3);

            String jam = c.getString(4);

            String status = c.getString(5);

            String telat = c.getString(6);

            anggota p = new anggota(id, nim, nama, tanggal, jam, status, telat);

            anggotaArrayList.add(p);
        }

        if(!(anggotaArrayList.size() < 1))
        {
            recyclerView.setAdapter(mAdapter);
        }


    }
}